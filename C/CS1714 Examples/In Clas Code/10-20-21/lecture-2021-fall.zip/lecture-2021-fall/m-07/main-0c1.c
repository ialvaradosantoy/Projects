#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include"product.h"

int main(int argc, char* argv[])
{
	srand(time(0));
	int n=0;
	char fileName[50];
	printf("Enter the filename : ");
	scanf("%s", fileName);
	FILE* fp;
	fp = fopen(fileName, "r"); // open file
	if(fp == NULL)
	{
		printf("ERROR: input file not opened successfully\n");
		return 1; // exit(0);
	}
	// how many products / lines in the file -- read file
	char tmp[100];
	fgets(tmp, 100, fp);
	while(fgets(tmp, 100, fp) != NULL) // (!feof(fp))
	{
		n++;
	}
	rewind(fp);
	printf("Number of products in file = %d\n", n);
	Product* products = createProducts(n); // (int*)malloc(n*sizeof(int)); // int products[n];
	// char productName[n][20];
	setProductInfo(products, n, fp); //read file and fill the array with data
	fclose(fp); // file close
	Product bestProduct = mostExpensiveProduct(products, n);
	FILE* outFP;
    outFP = fopen("bestProduct.txt", "w"); // open file
    if(outFP == NULL)
    {
        printf("ERROR: input file not opened successfully\n");
        return 1; // exit(0);
    }
	fprintf(outFP, "Product with the highest price : %lf,%d,%s\n", bestProduct.price, bestProduct.id, bestProduct.name);
	fclose(outFP);

	free(products);
	return 0;
}
