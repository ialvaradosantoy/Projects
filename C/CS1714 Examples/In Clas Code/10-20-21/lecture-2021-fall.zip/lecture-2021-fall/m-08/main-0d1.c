#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include"product.h"

int main(int argc, char* argv[]) // array or array of characters = array of strings
{
	printf("Number of command line arguments = %d\n\n", argc);
	int i=0;
	for(i=0; i<argc; i++)
		printf("argument %d = %s\n", i, argv[i]);

	if(argc < 3)
	{
		printf("ERROR : USAGE : ./exe inFileName outFileName\n");
		return 1;
	}

	srand(time(0));
	int n=0;
	//char fileName[50];
	//printf("Enter the input file name : ");
	//scanf("%s", fileName);

	FILE* fp;
	fp = fopen(argv[1], "r");
	if(fp == NULL)
	{
		printf("ERROR : File not opened successfully\n");
		return 1;
	}
	char tmp[100];
	fgets(tmp, 100, fp); //read header line and ignore it
	while(fgets(tmp, 100, fp) != NULL) // (!feof(fp))
	{
		n++;
	}
	rewind(fp);
	printf("Number of products in the file = %d\n", n);
	Product* products = createProducts(n); // (int*)malloc(n*sizeof(int)); // int arr[n];
	setProductInfo(products, n, fp);
	fclose(fp);

	Product bestProduct = mostExpensiveProduct(products, n);
	FILE* outFP;
    outFP = fopen(argv[2], "w");
    if(outFP == NULL)
    {
        printf("ERROR : output file not opened successfully\n");
        return 1;
    }
	fprintf(outFP, "Product with the highest price - %lf,%d,%s\n", bestProduct.price, bestProduct.id, bestProduct.name);
	fclose(outFP);

	free(products);
	return 0;
}
