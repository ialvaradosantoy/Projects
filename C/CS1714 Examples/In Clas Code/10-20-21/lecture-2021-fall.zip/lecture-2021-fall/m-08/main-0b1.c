#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include"product.h"

int main(int argc, char* argv[])
{
	printf("Number of command line arguments = %d\n\n", argc);
	int i=0;
	for(i=0; i<argc; i++)
		printf("argument %d = %s\n", i, argv[i]);

	if(argc < 3)
	{
		printf("ERROR: USAGE: ./exename inputfile.csv outputfile.txt\n");
		return 1;
	}
	srand(time(0));
	int n=0;
	//char filename[50];
	//printf("Enter the input file name : ");
	//scanf("%s", filename);
	FILE* fp;
	fp = fopen(argv[1], "r");
	if(fp == NULL)
	{
		printf("ERROR: File not opened successfully\n");
		return 1;
	}
	char tmp[100];
	//fscanf(fp, "%s", tmp);
	fgets(tmp, 100, fp);
	while(fgets(tmp,100,fp) != NULL)//!feof(fp))
	{
		// read a line
		//fgets(tmp, 100, fp);
		//printf("%s", tmp);
		n++;
	}
	printf("Number of products in file = %d\n", n);
	rewind(fp);

	// price for 'n' products
	Product* products = createProducts(n); // (int*)malloc(n*sizeof(int));
	// Average price for 'n' products
	//double average;
	
	// set product prices randomly
	setProductInfo(products, n, fp);
	fclose(fp);

	// calculate average price of products
	//average = calculateAverageProductPrice(products, n);
	//printf("Average price for %d products = %lf\n", n, average);

	Product bestProduct = mostExpensiveProduct(products, n);

	FILE* outFP;
	outFP = fopen(argv[2], "w");
	if(outFP == NULL)
	{
		printf("ERROR: Could not open the output file successfully\n");
		return 1;
	}
	fprintf(outFP, "Product with the highest price = %s,%d,%lf\n", bestProduct.name, bestProduct.id, bestProduct.price);
	fclose(outFP);

	free(products);
	return 0;
}
